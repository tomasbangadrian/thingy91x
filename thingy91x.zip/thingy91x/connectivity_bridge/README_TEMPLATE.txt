==============================
  Nordic Connectivity Bridge
==============================

This device is running Nordic's Connectivity bridge application.

Depending on configuration, the Connectivity bridge can offer the following functions:
* UART-USB bridge for two UART ports
* UART-BLE bridge for the first port using Nordic UART Service

Create a board-specific README file before deploying your firmware.
